package ndn.layer2;

public class L2Message {

}
