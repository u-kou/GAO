package ndn.nfd.datastructure;

/**
 * RIB のエントリ
 * @author taku
 *
 */
public class RIBEntry {

}
