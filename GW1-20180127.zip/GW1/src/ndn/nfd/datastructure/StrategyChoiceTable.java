package ndn.nfd.datastructure;

/**
 * Strategy Choice Table
 * @author taku
 *
 */
public class StrategyChoiceTable extends Table {

	public StrategyChoiceTable() {}
	
}
