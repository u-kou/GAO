package manager;

/**
 * FR が移動先に到着したときのリスナ
 * @author taku
 *
 */
public interface ArrivedListener {

	public void onArrived();
	
}
