package info;

import java.util.List;

/**
 * ルート情報
 * @author taku
 *
 */
public class RouteInfo {

	public List<String> names;

}
