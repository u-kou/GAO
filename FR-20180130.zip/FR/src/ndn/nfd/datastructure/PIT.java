package ndn.nfd.datastructure;

/**
 * PIT
 * @author taku
 *
 */
public class PIT extends Table {

}
