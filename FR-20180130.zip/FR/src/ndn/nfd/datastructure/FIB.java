package ndn.nfd.datastructure;

/**
 * FIB
 * @author taku
 *
 */
public class FIB extends Table {

}
