package info;

import java.util.List;

import datastructure.NodeTableEntry;

/**
 * ノード情報
 * @author taku
 *
 */
public class Info {

	public List<String> names;
	public List<NodeTableEntry> ntes; 
	
}
