package ndn.nfd.face;

import ndn.nfd.datastructure.Table;

/**
 * Data Filter を格納するテーブル
 * @author taku
 *
 */
public class DataFilterTable extends Table {
	
}
