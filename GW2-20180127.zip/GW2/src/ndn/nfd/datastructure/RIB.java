package ndn.nfd.datastructure;

/**
 * RIB 
 * ※今のところ使わない
 * @author taku
 *
 */
public class RIB {

}
